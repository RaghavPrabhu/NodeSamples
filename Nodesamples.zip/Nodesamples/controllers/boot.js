/*
 * Boot context to initialize all components
 * Author : Raghav Prabhu
 * Version : 1.0
 */

var db = require('../lib/Datastore'),
    cjson = require('../lib/cjson'),
    mediaService = require('../services/mediaservice'),
    conf = cjson.load('config.json'),
    logger = require("../j_logger.js").getLogger(),
    networkManager = require('../services/networkManager'),
    heartBeatService = require("../services/heartbeat.js"),
    clientBridge = require("../services/clientbridge.js"),
    eventQueue = require('simplequeue'),
    youtube = require('youtube-node'),
    childProcess = require('child_process');
    Sync = require('sync'), Future = Sync.Future;

var exec = childProcess.exec;
//var nowPlayQueue = IndexedMap();


var application = {

    initialize: function () {
        application.startNetwork();
        application.database();
    },

    database: function () {
        db.init(null, null, conf.sqlite.database, conf.sqlite.driver,
            function (result) {
                if (result) {
                    logger.log('info', 'database created ');
                    application.mediaService();
                    application.bootKiosk();
                }
            });
    },

    startNetwork: function () {
        Sync(function() {
          logger.info("NetworkService Initiating...");
          networkManager.init(conf.hotspot, function () {
//              networkManager.networkInit(conf.essid, function () {
                  logger.info('ClientBridge Initiating...');
                  clientBridge.init();
                  logger.log('info', "HeartBeatService Initiating...");
                  heartBeatService.init();
//              });
          });
        });

    },

    mediaService: function () {
        logger.log('info', 'Media service intialize ' + conf.params);
        //Initialize the media services
        conf.params.youtube = youtube;
        mediaService.init('FileMedia', conf.params, function (err, result) {
            if (!err) {
                logger.log("Result " + result);
            } else {
                logger.log('error', 'Media service error ' + err);
            }
        });
    },

    //Call this function to invoke the browser on  HDMI connected devices
    bootKiosk: function () {
        //TODO: Needs to check and execute only if HDMI is on
        logger.log('info', 'Kiosk browser initialization ');
        exec('xinit /mnt/jamstaleopard/config/kiosk.sh',
            function (error, stdout, stderr) {
                if (error) {
                    logger.log('error', 'Browser intialization error ' + error);
                }
                if (stderr) {
                    logger.log('error', 'Browser intialization error ' + stderr);
                }
                if (stdout) {
                    logger.log('info', 'Browser started ' + stdout);
                }
            });
    }
    /*hearBeatService : function(){
     logger.log('info', 'Hear Beat Service Initializing...' + conf.params);
     hearBeat.init(conf.params);
     },

     notifyClientsService : function(){
     logger.log('info', 'Notify Client Service Initializing...' + conf.params);
     notifyClients.init(conf.params);
     }
     */
};

module.exports = application;

application.initialize();
