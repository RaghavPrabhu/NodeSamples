/** @FileName persistence-control.js
 @Description A generic persistence model for MongoDb, MySQL and so on.
 @author Raghav Prabhu
 **/

var Injector = require("./injector");
var MongoDriver = require("./mongo");
var SqliteDriver = require("./sqlite"),
    logger = require('../../j_logger').getLogger();
var cjson = require('cjson');

var db_driver;

/**
 * Database driver injection method
 */
var DatabaseAdapter = {
	init : function DB_init(host, port, database, driver, callBack) {
        logger.info('DatabaseAdapter init Function');
		DBAdapter = function(Driver) {
			db_driver = Driver;
		};

		Injector.register('Driver', SqliteDriver);
		Injector.process(DBAdapter);
		logger.info('host : ' + host + ' : port : ' + port + ' : database : '
            + database);
		if (driver === 'mongodb') {
            logger.info('Initiate MongoDriver...');
			MongoDriver.init(host, port, database);
		} else if (driver === 'sqlite') {
            logger.info('Initiate SqliteDriver...');
			SqliteDriver.init(database);
		}
		if (callBack !== undefined) {
			callBack(db_driver);
		}

	},

	/**
	 * Save method
	 */
	save : function(tableName, value, callback) {
        logger.info('DatabaseAdapter save Function');
		if ((tableName != 'undefined') && (value != 'undefined')) {
            try {
                db_driver.save(tableName, value, callback);
            }catch(e){
                logger.error('Error at DatabaseAdapter save Function: ', e);
            }
		} else {
			logger.warn('All parameters are required');
		}
	},

	read : function(tableName, query, callback) {
        logger.info('DatabaseAdapter read Function');
		if ((tableName != 'undefined') && (query != 'undefined')) {
            try {
                db_driver.read(tableName, query, callback);
            }catch(e){
                logger.error('Error at DatabaseAdapter read Function: ', e);
            }
		} else {
			logger.warn('All parameters are required');
		}
	},

	readById : function(tableName, id, callback) {
        logger.info('DatabaseAdapter readById Function');
		if ((tableName != 'undefined') && (id != 'undefined')) {
            try {
                db_driver.readById(tableName, id, callback);
            }catch(e){
                logger.error('Error at DatabaseAdapter readById Function: ', e);
            }
		} else {
			logger.warn('All parameters are required');
		}
	},

	update : function(tableName, query, updateValue, callback) {
        logger.info('DatabaseAdapter update Function');
		if ((tableName != 'undefined') && (query != 'undefined')
            && (updateValue != 'undefined')) {
            try {
                db_driver.update(tableName, query, updateValue, callback);
            }catch(e){
                logger.error('Error at DatabaseAdapter update Function: ', e);
            }
		} else {
			logger.warn('All parameters are required');
		}
	},

	deleteData : function(tableName, query, callback) {
        logger.info('DatabaseAdapter deleteData Function');
		if ((tableName != 'undefined') && (query != 'undefined')) {
            try {
                db_driver.deleteData(tableName, query, callback);
            }catch(e){
                logger.error('Error at DatabaseAdapter deleteData Function: ', e);
            }
		} else {
			logger.warn('All parameters are required');
		}
	},

	createTable : function(query, callback) {
        logger.info('DatabaseAdapter createTable Function');
		if ((query !== undefined) && (query !== '')) {
            try {
                db_driver.createTable(query, callback);
            }catch(e){
                logger.error('Error at DatabaseAdapter createTable Function: ', e);
            }
		} else {
			logger.warn('Parameter required');
		}
	},

	getByQuery : function(query, callback) {
        logger.info('DatabaseAdapter getByQuery Function');
		if ((query !== undefined) && (query !== '')) {
            try {
                db_driver.getByQuery(query, callback);
            }catch(e){
                logger.error('Error at DatabaseAdapter getByQuery Function: ', e);
            }
		} else {
			logger.warn('Parameter required');
		}
	}

};

//Exporting this module
module.exports = DatabaseAdapter;
