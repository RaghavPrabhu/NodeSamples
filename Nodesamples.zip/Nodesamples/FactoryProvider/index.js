/** FileSystem.js
 *
 *  Factory pattern applied to create media type node objects
 *
 *  @author Raghav Prabhu
 **/

var AbstractFactory = require('abstract-factory'),
    FileProvider = require('filemediaprovider'),
    YouTubeProvider = require('youtubeprovider'),
    VimeoProvider = require('vimeoprovider'),
    logger = require("../../j_logger.js").getLogger();

var App = function (abstractFactory) {
    this.myInterface = abstractFactory;
};

App.prototype.getFactoryObject = function () {
    // instead of referencing api directly, eg originalApi.returnData();
    return this.myInterface.getFactory('api');
};

var providerFactory = function (factory) {
    return new App(new AbstractFactory({
        api: factory
    }));
};

var mediafactory = {
    execute: function (mediaType, rootPath, isDirectory, media, callBack) {
        if (mediaType === 'FileMedia') {
            logger.info('FileMedia search at RootPath: ', rootPath);
            providerFactory(FileProvider).getFactoryObject().readRecursive(
                rootPath, isDirectory, function (result) {
                    callBack(result);
                });
        } else if (mediaType === 'YouTube') {
            logger.info('YouTube search query using Media Provider for',
                rootPath);
            providerFactory(YouTubeProvider).getFactoryObject().getYoutubeData(
                rootPath, media, function (youTubeVideos) {
                    callBack(youTubeVideos);
                });
        } else if (mediaType === 'Vimeo') {
            logger.info('Vimeo search query using Media Provider for',
                rootPath);
            providerFactory(VimeoProvider).getFactoryObject().getVideos(
                rootPath, media, function (vimeoVideos) {
                    callBack(vimeoVideos);
                });
        } else {
            logger.info('Check your media type...');
            callBack('Check your media type... !');
        }
    },
    fileProvider: FileProvider
};

var mediafactoryobject = {
		execute: function(mediaType, rootPath, isDirectory, media, callBack){
			
		}
};


module.exports = mediafactory;

