 /*
 * IPC Listener for File watcher
 * Author : Raghav Prabhu
 * Version : 1.0
 */
var messenger = require('messenger'),
    cjson = require('../lib/cjson'),
    conf = cjson.load('config.json'),
    mediaService = require('../services/mediaservice'),
    nowPlayManager = require('../services/nowPlayManager'),
    logger = require("../j_logger.js").getLogger(),
    eventMessage = require('../services/eventMessage');

var ipcServer = {

    init: function (params) {
        createIPCListener(params);
    },

    saveData: function (params) {
        var message = {
            "Event_type": "driverInsert",
            "Event_Parameters": {
                "popupInfo": "Media source Added ..."
            },
            "Event_Module": "popupmessage"
        };
        eventMessage.generateMessage(message);
        mediaService.initFileMedia('FileMedia', params, function (result) {
            nowPlayManager.init();
            logger.info(':::::::;;;;;; IPC INSERT MEDIA CALLBACK :: ', result);
        });
    },

    deleteData: function (driveName) {
        var message = {
            "Event_type": "driverRemoved",
            "Event_Parameters": {
                "popupInfo": "Media source" + driveName + " Removed ..."
            },
            "Event_Module": "popupmessage"
        };
        eventMessage.generateMessage(message);
        mediaService.deleteDrive(driveName, function (result) {
            logger.info(' :::::::::::;; LISTION deleteData :::::;;;', result);
        });
    }

};

module.exports = ipcServer;

function createIPCListener(params) {
    try {
        logger.log('info', 'IPC listener starting..');
        var host = params.ipc.serverIP;
        var port = params.ipc.serverPort;
        var ipc = messenger.createListener(host + ':' + port);
        ipc.on('File', function (m, data) {
            logger.info(' IPC data ' + data.path + ' is Directory :'
                + data.isDirectory);
            var params = {
                rootPath: '/media/' + data.path,
                mimeType: 'audio/mpeg',
                isDirectory: data.isDirectory,
                source_id: data.path
            };
            ipcServer.saveData(params);
        });
        ipc.on('File_Delete', function (m, data) {
            logger.info(' IPC data ' + data.path + ' is Directory :'
                + data.isDirectory);
            ipcServer.deleteData(data.path);
        });
        logger.log('info', 'IPC listener started.. ' + ipc);
    } catch (e) {
        logger.log('error', 'Problem in generating IPC listener');
    }
}

ipcServer.init(conf);
