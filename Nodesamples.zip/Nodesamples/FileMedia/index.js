/** FileSystem.js
 *
 *  Read the device file system and retrieve the file details in asynchronous mode.
 *  It will filter the files based the required mime type.
 *
 *  @author Raghav Prabhu
 **/
var _ = require('underscore'),
    util = require('util'),
    mime = require('mime'),
    fs = require('fs'),
    vm = require('fluent-ffmpeg'),
    mm = require('musicmetadata'),
    path = require('path'),
    imagemagick = require('imagemagick-native'),
    logger = require('../../../../j_logger').getLogger();

var conf = {},
    sourceid = 'FileMedia';

var FileSystem = {

    /**
     * Read directories recursively and get the music metadata of the MP3
     * files.
     *
     * @param initParam : A key value parameters which have several keys like Root-Path, MimeType
     * @param callback : Callback function will be called along with the music metadata details of a music file
     */
    readRecursive: function (rootPath, isDirectory, callback) {
        if ((isDirectory === undefined) || (isDirectory)) {
            readDirRecursive(rootPath, function (err, file) {
                if (file) {
                    if (!FileSystem.isUnixHiddenPath(file)) {
                        FileSystem.getMetaData(file, callback);
                        logger.info('Getting meta data...', file);
                    }
                } else {
                    logger.error('Problem in reading files ', err);
                }
            });
        } else {
            FileSystem.getMetaData(rootPath, callback);
        }
    },

    /**
     * Checks whether a path starts with or contains a hidden file or a folder.
     * @param {string} source - The path of the file that needs to be validated.
     * returns {boolean} - `true` if the source is blacklisted and otherwise `false`.
     */
    isUnixHiddenPath: function (path) {
        return (/(^|.\/)\.+[^\/\.]/g).test(path);
    },

    getMetaData: function (filePath, callBack) {
        /** Checks the valid mime type */
        if (mime.lookup(filePath).search('video') === 0) {
            FileSystem.getVideoMetaData(filePath, callBack);
        } else if (mime.lookup(filePath).search('audio') === 0) {
            FileSystem.getMusicMetadata(filePath, callBack);
        }
    },

    getVideoMetaData: function (mediaFilePath, callback) {
        var result = {};
        result.title = path.basename(mediaFilePath);
        result.artist = ['Unkonwn'];
        result.albumartist = ['Unkonwn'];
        result.album = 'Unkonwn';
        result.year = 'Unkonwn';
        result.picture = '/opt/jamstaleopard/icon.png';
        result.path = mediaFilePath;
        result.source_id = sourceid;
        callback(result);
    },

    /**
     * Fetch music metadata using 'MusicMetaData' library by passing the file path
     *
     * @param mediaFilePath : Root directory
     * @param callback : Callback function will be called along with the music metadata details of a music file
     */
    getMusicMetadata: function (mediaFilePath, callback) {
        var parser = new mm(fs.createReadStream(mediaFilePath));
        //listen for the metadata event
        parser.on('metadata', function (result) {
            if (result) {
                if (callback) {
                    var filename = null;
                    if (result.picture.length === undefined
                        || result.picture.length === null) {
                        result.picture = "icon.png";
                    } else {
                        try {
                            var imageName = result.title;
                            // removing special characters in the file name for thumbnail
                            imageName = imageName.replace(/[^a-zA-Z0-9]/g, "").replace(/[\s]/g, "");
                            filename = '%jamstaImage%' + imageName;
                            //Checks if this file exists
                            if (!fs.existsSync(filename)) {
                                //Image Magic file for thumbnail
                                var resizedBuffer = imagemagick.convert({
                                    srcData: result.picture[0].data,
                                    width: 44,
                                    height: 45,
                                    resizeStyle: "aspectfill",
                                    quality: 80,
                                    format: 'JPEG'
                                });
                                fs.writeFileSync(filename, resizedBuffer, 'binary');
                            }
                            result.picture = filename;
                        } catch (e) {
                            logger.error('Problem in writing image thumbnail ', e);
                            result.picture = "icon.png";
                        }
                    }
                    result.path = mediaFilePath;
                    result.source_id = sourceid;
                    callback(result);
                }
            }
        });
    }
};

//Exporting this module
module.exports = FileSystem;

/**
 * This function will read the directory recursively and calls back by the called
 * function, if it is a file else it recursively call this function by itself until
 * it gets the files.
 *
 */
var readDirRecursive = function (dir, callBack) {
    fs.readdir(dir, function (err, list) {
        var pending = list.length;
        if (pending) {
//            list = _.shuffle(list);
            list.forEach(function (file) {
                file = dir + '/' + file;
                fs.stat(file, function (err, stat) {
                    if (stat && stat.isDirectory()) {
                        //This is directory, so it calls the function by itself
                        readDirRecursive(file, callBack);
                    } else {
                        callBack(null, file);
                    }
                });
            });
        }
    });
};



