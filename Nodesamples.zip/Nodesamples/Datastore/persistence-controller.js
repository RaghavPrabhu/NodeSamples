
/** @FileName persistence-control.js
    @Description A generic persistence model for MongoDb, MySQL and so on.
    @author Raghav Prabhu
**/ 

var Injector = require("./injector");
var MongoDriver = require("./mongo");
var SqliteDriver = require("./sqlite");
var cjson = require('cjson');

var db_driver;

/**
 * Database driver injection method
 */
//var DatabaseAdapter;
//module.exports = DatabaseAdapter;
var DatabaseAdapter = {
	init : function DB_init(host, port, database, driver) {
		DBAdapter = function(Driver) {
			db_driver = Driver;
		};

		Injector.register('Driver', SqliteDriver);
		Injector.process(DBAdapter);
        console.log('host' + host + 'port' + port + 'database' + database);
	//	var conf = cjson.load('config.json');
        if(driver === 'mongodb')
        {
            MongoDriver.init(host,port,database);
        }else if(driver === 'sqlite'){
            SqliteDriver.init(database);
        }

    //    MongoDriver.init(conf.host,conf.port,conf.database);
    //    SqliteDriver.init(database);
	},
	
	/**
	 * Save method
	 */
	save : function(tableName, value, callback) {
		if ((tableName != 'undefined') && (value != 'undefined')) {
			db_driver.save(tableName,value,callback);
		}else {
			console.log('All parameters are required');
		}
	},
			
	read : function(tableName,query,callback){
		if ((tableName != 'undefined') && (query != 'undefined')) {
			db_driver.read(tableName,query,callback);
		}else {
			console.log('All parameters are required');
		}
	},
	
	readById : function(tableName,id,callback){
		if ((tableName != 'undefined') && (id != 'undefined')) {
			db_driver.readById(tableName,id,callback);
		}else {
			console.log('All parameters are required');
		}
	},
	
	update : function(tableName,query,updateValue,callback){
		if ((tableName != 'undefined') && (query != 'undefined')
            && (updateValue != 'undefined')) {
			db_driver.update(tableName,query,updateValue,callback);
		}else {
			console.log('All parameters are required');
		}
	},

     deleteData : function(tableName,query,callback){
        console.log('::::DB CONTROL DELETE DATA:::');
        if ((tableName != 'undefined') && (query != 'undefined')) {
            db_driver.deleteData(tableName,query,callback);
        }else {
            console.log('All parameters are required');
        }
    },

    createTable : function(query,callback){
        if ((query != 'undefined') && (query != '')) {
            db_driver.createTable(query,callback);
        }else {
            console.log('Parameter required');
        }
    }
};

//Exporting this module
module.exports = DatabaseAdapter;
